package com.simona.simonaimmobilier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimonaImmobilierApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimonaImmobilierApplication.class, args);
	}

}
